const StorageKeys={
    USER:'user',
    TOKEN:'access_token',
    USERID:'user_id',
    NAMEUSER:'name_user'
}

export default StorageKeys;