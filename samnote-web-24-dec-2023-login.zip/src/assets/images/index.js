const images = {
  logo: require("./logo.png"),
  bgrLogin: require("./bgr-login.png"),
};

export default images;
