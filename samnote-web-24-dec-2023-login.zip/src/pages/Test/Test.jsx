const Test = () => {
  return (
    <div
      style={{
        backgroundColor: "#333",
      }}
    >
      <h1
        style={{
          textAlign: "center",
          color: "#fff",
        }}
      >
        Test
      </h1>
    </div>
  );
};

export default Test;
